#ifndef __POINT_H__
#define __POINT_H__

typedef struct _point{
	int x=0;
	int y=0;
}Point;

#endif