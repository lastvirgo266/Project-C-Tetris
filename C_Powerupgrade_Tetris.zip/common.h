#ifndef __COMMON_H__
#define __COMOON_H__

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>
#include<Windows.h>

#endif
